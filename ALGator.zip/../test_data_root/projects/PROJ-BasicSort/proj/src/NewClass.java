/**
 *
 * @author tomaz
 */
public class NewClass {

}
