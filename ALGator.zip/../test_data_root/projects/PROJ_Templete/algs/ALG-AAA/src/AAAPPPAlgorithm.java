/**
 *
 * @author ...
 */
public class AAAPPPAlgorithm extends PPPAbsAlgorithm {

  // TODO: write the algorithm body (execute method) 
  
  //@Override
  //public void execute(...) {
  //} 
}
