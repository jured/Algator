import si.fri.algotest.execute.Counters;
/**
 *
 * @author tomaz
 */
public class JavaSortAlgorithm_COUNT extends BasicSortAbsAlgorithm {

  public void execute(int[] data) {
    java.util.Arrays.sort(data);
  }

}

