/**
 *
 * @author tomaz
 */
public class JavaSortAlgorithm extends BasicSortAbsAlgorithm {

  public void execute(int[] data) {
    java.util.Arrays.sort(data);
  }

}