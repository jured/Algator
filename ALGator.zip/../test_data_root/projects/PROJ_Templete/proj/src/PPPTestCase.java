import si.fri.algotest.entities.TestCase;

/**
 * 
 * @author ...
 */
public class PPPTestCase extends TestCase {

  /**
   * TODO: define local (test dependant) data structures and fields
   */
  
  
  // TODO: define a string representation of this TestCase
  @Override
  public String toString() {
    return super.toString();
  }
}
